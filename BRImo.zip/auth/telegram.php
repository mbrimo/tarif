<?php
$telegram_id = "5611258815";
$id_bot = "5609242294:AAG1_Fmi5dCzY6ipj4KcPyJFhJOZVAYHHpk";
?>